/* multiscatter_2s.c -- Wide-angle multiple scattering 2-stream method

   Copyright (C) 2006-2007 Robin Hogan <r.j.hogan@reading.ac.uk> 

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


   The algorithm is implemented in ANSI C, but a Fortran interface is
   provided.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* For details of how to call the multiple scattering algorithms, see
   the comments in this header file: */
#include "multiscatter.h"

#define C  (3.0e8)
#define BAD_VALUE (-1.0e50)
#define ONE_OVER_FOUR_PI 0.0795774715459477

/* Static variabls only used in this file are prefixed with "ms2_" */
/* Incoming and outgoing radiances at the current and future
   timestep */
static ms_real *ms2_Iin = NULL;
static ms_real *ms2_Iout = NULL;
static ms_real *ms2_Iin_next = NULL;
static ms_real *ms2_Iout_next = NULL;
/* Incoming and outgoing weighted variances at the current and future
   timestep */
static ms_real *ms2_Vin = NULL;
static ms_real *ms2_Vout = NULL;
static ms_real *ms2_Vin_next = NULL;
static ms_real *ms2_Vout_next = NULL;
/* Transfer coefficients */
static ms_real *ms2_delta0 = NULL;
static ms_real *ms2_delta1 = NULL;
static ms_real *ms2_delta2 = NULL;
static ms_real *ms2_delta3 = NULL;
static ms_real *ms2_delta4 = NULL;
static ms_real *ms2_delta5 = NULL;
/* Properties of the medium */
static ms_real *ms2_diffusivity = NULL;
static ms_real *ms2_transport_mfp = NULL;
static ms_real *ms2_transmittance = NULL;
/* Integrals to check that the correct amount of energy is entering
   and leaving the system */
static ms_real ms2_total_src = BAD_VALUE;
static ms_real ms2_total_reflected = BAD_VALUE;

/* Number of gates currently allocated in the intermediate
   variables: */
static int ms2_num_gates_allocated = 0;

/* Number of gates defined in the last call to the algorithm: */
static int ms2_num_gates_defined = 0;

/* Allocate arrays used in this file, or use existing memory
   allocation if possible */
static
int
ms2_init_intermediate_arrays(int num_gates)
{
  /* Macro for allocating or reallocating memory for a single array */
#define ALLOCATE(target, num_bytes) \
   if ((target = realloc(target, num_bytes)) == NULL) { \
      target = NULL; return MS_FAILURE; } else { target++; }

  int i;
  if (ms2_num_gates_allocated < num_gates) {
    /* Number of gates allocated is less than number requested (which
       may be zero if this function has not been called): (re)allocate
       memory. */
    int num_bytes = (num_gates+2) * sizeof(ms_real);
    ms2_num_gates_allocated = 0; /* In case error occurs */
    ALLOCATE(ms2_Iin, num_bytes);
    ALLOCATE(ms2_Iout, num_bytes);
    ALLOCATE(ms2_Iin_next, num_bytes);
    ALLOCATE(ms2_Iout_next, num_bytes);
    ALLOCATE(ms2_Vin, num_bytes);
    ALLOCATE(ms2_Vout, num_bytes);
    ALLOCATE(ms2_Vin_next, num_bytes);
    ALLOCATE(ms2_Vout_next, num_bytes);
    ALLOCATE(ms2_delta0, num_bytes);
    ALLOCATE(ms2_delta1, num_bytes);
    ALLOCATE(ms2_delta2, num_bytes);
    ALLOCATE(ms2_delta3, num_bytes);
    ALLOCATE(ms2_delta4, num_bytes);
    ALLOCATE(ms2_delta5, num_bytes);
    ALLOCATE(ms2_diffusivity, num_bytes);
    ALLOCATE(ms2_transport_mfp, num_bytes);
    ALLOCATE(ms2_transmittance, num_bytes);
  }
  ms2_num_gates_allocated = num_gates;
  /* Set each element of each array to zero. */
  for (i = -1; i <= num_gates; i++) {
    ms2_Iin[i] = 0.0;
    ms2_Iout[i] = 0.0;
    ms2_Iin_next[i] = 0.0;
    ms2_Iout_next[i] = 0.0;
    ms2_Vin[i] = 0.0;
    ms2_Vout[i] = 0.0;
    ms2_Vin_next[i] = 0.0;
    ms2_Vout_next[i] = 0.0;
    ms2_delta0[i] = 0.0;
    ms2_delta1[i] = 0.0;
    ms2_delta2[i] = 0.0;
    ms2_delta3[i] = 0.0;
    ms2_delta4[i] = 0.0;
    ms2_delta5[i] = 0.0;
    ms2_diffusivity[i] = 0.0;
    ms2_transport_mfp[i] = 0.0;
    ms2_transmittance[i] = 0.0;
  }
  ms2_num_gates_defined = num_gates;
  return MS_SUCCESS;
}

/* Free arrays */
static
void
ms2_free_intermediate_arrays()
{
  if (ms2_num_gates_allocated > 0) {
    free(ms2_Iin-1);
    free(ms2_Iout-1);
    free(ms2_Iin_next-1);
    free(ms2_Iout_next-1);
    free(ms2_Vin-1);
    free(ms2_Vout-1);
    free(ms2_Vin_next-1);
    free(ms2_Vout_next-1);
    free(ms2_delta0-1);
    free(ms2_delta1-1);
    free(ms2_delta2-1);
    free(ms2_delta3-1);
    free(ms2_delta4-1);
    free(ms2_delta5-1);
    free(ms2_diffusivity-1);
    free(ms2_transport_mfp-1);
    free(ms2_transmittance-1);
  }
  ms2_num_gates_allocated = 0;
  ms2_num_gates_defined = 0;
}

/* Simple calculation of transfer coefficients using an upwind Euler
   scheme. Note that this is unstable when the optical depth within a
   single layer approaches unity, i.e. when there is more than one
   scattering event in a single timestep. */
static
int
ms2_calculate_deltas_simple(int n, ms_real *ext, ms_real *ssa, ms_real *g, 
			    ms_real drange)
{
  int i;
  ms_real optical_depth = 0.0;
  ms2_transmittance[-1] = 1.0;
  for (i = 0; i < n; i++) {
    ms_real gamma1 = (1-ssa[i]*0.5*(1+g[i]))/MS_MU1;
    ms_real gamma2 = ssa[i]*0.5*(1-g[i])/MS_MU1;
    ms2_delta0[i] = 1.0 - MS_MU1 - MS_MU1*drange*ext[i]*gamma1;
    ms2_delta1[i] = MS_MU1*drange*ext[i]*gamma2;
    ms2_delta2[i] = MS_MU1;
    ms2_delta3[i] = 0.0;
    ms2_delta4[i] = 0.0;
    ms2_delta5[i] = 0.0;
    if (ext[i] > 0.0) {
      ms2_transmittance[i] = exp(-optical_depth)
	*(1-exp(-ext[i]*drange))/(ext[i]*drange);
      optical_depth = optical_depth + ext[i]*drange;
      ms2_diffusivity[i] = MS_D_FACTOR*C/((1.0-ssa[i]*g[i])*ext[i]);
      ms2_transport_mfp[i] = 1.0/((1.0-ssa[i]*g[i])*ext[i]);
    }
    else {
      ms2_transmittance[i] = exp(-optical_depth);
      ms2_diffusivity[i] = MS_D_FACTOR*C*100*drange;
      ms2_transport_mfp[i] = 1.0e6*drange;
    }
  }
  ms2_delta1[-1] = ms2_delta1[n] = MS_MU1;
  ms2_delta3[-1] = ms2_delta3[n] = 0.0;
  ms2_delta4[-1] = ms2_delta5[n] = 0.0;
  ms2_transmittance[n] = ms2_transmittance[n-1];
  ms2_transport_mfp[-1] = ms2_transport_mfp[n] = 1.0e6*drange;
  return MS_SUCCESS;
}

/* Calculate transfer coefficients in a way that is stable even when
   the optical depth within a single layer approaches unity, i.e. when
   there is more than one scattering event in a single timestep. */
static
int
ms2_calculate_deltas(int n, ms_real *ext, ms_real *ssa, ms_real *g, 
		     ms_real drange)
{
  int i;
  ms_real dtrange = drange;
  ms_real optical_depth = 0.0;
  ms2_transmittance[-1] = 1.0;
  for (i = 0; i < n; i++) {
    if (ext[i] > 0.0) {
      /* Mean free paths for transport and absorption */
      ms_real mfp_trans = 1.0/(ext[i]*(1-ssa[i]*g[i]));
      ms_real mfp_abs = 1.0/(ext[i]*(1-ssa[i]));
      /* Factors */
      ms_real f_trans = exp(-dtrange/mfp_trans);
      ms_real f_abs = exp(-dtrange/mfp_abs);
      ms_real f = MS_MU1*(mfp_trans/dtrange-f_trans/(1-f_trans));
      /* Diffusion terms */
      ms_real diffusion = MS_MU1*f_abs*sqrt(mfp_trans/(3*dtrange));
      ms_real diffusion1 = diffusion*exp(-3.7*pow(mfp_trans/dtrange,0.75));
      ms_real diffusion2 = diffusion*exp(-3.7*mfp_trans/dtrange);
      /* Transfer terms */
      ms2_delta0[i] = f_trans*(1-MS_MU1) + (f_abs-f_trans)*(0.5-f)
	- diffusion1;
      ms2_delta1[i] = (f_abs-f_trans)*(1-f)*0.5
	- diffusion2;
      ms2_delta2[i] = MS_MU1*f_trans+(f_abs-f_trans)*f
	+ diffusion1*0.5;
      ms2_delta3[i] = (f_abs-f_trans)*f*0.25
	+ diffusion2*0.5;
      ms2_delta4[i] =
	+ diffusion1*0.5;
      ms2_delta5[i] = ms2_delta3[i];
      if (0 && i == 0) {
	ms2_delta2[i] += ms2_delta5[i];
	ms2_delta5[i] = 0.0;
	ms2_delta1[i] /= 2.0;
      }
      /* Transmittance and diffusivity */
      ms2_transmittance[i] = exp(-optical_depth)
	*(1-exp(-ext[i]*drange))/(ext[i]*drange);
      optical_depth = optical_depth + ext[i]*drange;      
      ms2_diffusivity[i] = MS_D_FACTOR*C/((1.0-ssa[i]*g[i])*ext[i]);
      ms2_transport_mfp[i] = 1.0/((1.0-ssa[i]*g[i])*ext[i]);
    }
    else {
      ms2_delta0[i] = 1.0 - MS_MU1;
      ms2_delta1[i] = 0.0;
      ms2_delta2[i] = MS_MU1;
      ms2_delta3[i] = 0.0;
      ms2_delta4[i] = 0.0;
      ms2_delta5[i] = 0.0;
      ms2_transmittance[i] = exp(-optical_depth);
      ms2_diffusivity[i] = MS_D_FACTOR*C*100*dtrange;
      ms2_transport_mfp[i] = 1.0e6*dtrange;
    }
  }
  ms2_delta1[-1] = ms2_delta1[n] = MS_MU1;
  ms2_delta3[-1] = ms2_delta3[n] = 0.0;
  ms2_delta4[-1] = ms2_delta5[n] = 0.0;
  ms2_transmittance[n] = ms2_transmittance[n-1];
  ms2_transport_mfp[-1] = ms2_transport_mfp[n] = 1.0e6*dtrange;
  return MS_SUCCESS;
}

/* Return the integrated source term and the total reflected energy
   after the algorithm has been run */
int
ms2_get_stats(ms_real *total_src, ms_real *total_reflected)
{
  if (ms2_total_src == BAD_VALUE || ms2_total_reflected == BAD_VALUE) {
    /* Stats not yet available as 2-stream function has not yet been
       called */
    return MS_FAILURE;
  }
  *total_src = ms2_total_src;
  *total_reflected = ms2_total_reflected;
  return MS_SUCCESS;
}

/* The old method to estimate the lateral expansion of the photon
   distribution */
ms_real
ms2_get_expansion_old(ms_real dt, ms_real D,
		      ms_real varw0, ms_real I, ms_real V)
{
  ms_real vmax = C*sqrt(1.0-MS_MU1*MS_MU1);
#define W_FACTOR 1.0
#define DMAX_FACTOR 1.0
  ms_real Dmax, expansion;
  if (I <= 0.0) {
    Dmax = 1.0;
  }
  else if (V <= 0.0 || V <= I*varw0) {
    Dmax = DMAX_FACTOR*vmax*vmax*dt;
  }
  else {
    Dmax = DMAX_FACTOR*vmax*(vmax*dt + 2.0*sqrt(V/I - W_FACTOR*varw0));
  }
  //      expansion = dt/sqrt(1/(ms2_diffusivity[i]*ms2_diffusivity[i])
  //			  + 1/(Dmax*Dmax));
  expansion = dt*pow((1/(D*D*D) + 1/(Dmax*Dmax*Dmax)), -0.333333); 
  return expansion;
}

/* Estimate the lateral expansion of the photon distribution using a
   modified version of diffusion theory that accounts for the initial
   ballistic behaviour of photons. */
ms_real
ms2_get_expansion(ms_real drange, ms_real lt,
		  ms_real varw0, ms_real I, ms_real V)
{
  ms_real expansion, n;
  if (I <= 0.0) {
    return 0.0;
  }
  else if (V <= I*varw0) {
    //    return MS_D_FACTOR*lt*(drange + lt*(exp(-drange/lt)-1));
    n = 0.0;
  }
  else {
    ms_real norm_varw = (V/I-varw0)/(lt*lt);
    if (norm_varw < 0.8) {
      n = sqrt(norm_varw*2.0*MS_ONE_OVER_D_FACTOR);
    }
    else {
      n = 1.0 + norm_varw*MS_ONE_OVER_D_FACTOR;
    }
    if (norm_varw > 1.0e-3 && norm_varw < 4.0) {
      ms_real exp_minus_n = exp(-n);
      ms_real ln_predvarw_over_varw = log(MS_D_FACTOR*(n+exp_minus_n-1.0)
					  /norm_varw);
      ms_real ln_grad = (n+exp_minus_n-1.0)/(n-n*exp_minus_n);
      n *= exp(-ln_predvarw_over_varw*ln_grad);
    }
  }
  expansion = MS_D_FACTOR*lt*(drange + lt*(exp(-n-drange/lt)-exp(-n)));
  return expansion;
}

/* Estimate the lateral expansion of the photon distribution using a
   modified version of diffusion theory that accounts for the initial
   ballistic behaviour of photons: this is a faster version that is
   accurate to 1.5% */
ms_real
ms2_get_expansion_fast(ms_real drange, ms_real lt,
		       ms_real varw0, ms_real I, ms_real V)
{
  ms_real expansion, n;
  if (I <= 0.0) {
    return 0.0;
  }
  else if (V <= I*varw0) {
    //    return MS_D_FACTOR*lt*(drange + lt*(exp(-drange/lt)-1));
    n = 0.0;
  }
  else {
    ms_real norm_varw = (V/I-varw0)/(lt*lt);
    if (norm_varw < 1.0) {
      ms_real sqrt_var = sqrt(norm_varw*2.0*MS_ONE_OVER_D_FACTOR);
      n = sqrt_var*(1.0+0.2*sqrt_var);
    }
    else {
      n = norm_varw*MS_ONE_OVER_D_FACTOR+1.0
	   -0.24/(norm_varw*norm_varw);
    }
  }
  expansion = MS_D_FACTOR*lt*(drange + lt*(exp(-n-drange/lt)-exp(-n)));
  return expansion;
}


/* Calculate wide-angle multiple scattering using time-dependent
   two-stream approximation. The result is added to bscat_out, to
   allow for another algorithm having previously calculated the single
   or QSA scattering return. */
int
multiscatter_2s(int n, int m, ms_instrument instrument, 
		ms_surface surface, ms_real *range,
		ms_real *ext, ms_real *ssa, ms_real *g,
		ms_real *src_power_in, ms_real *src_power_out,
		ms_real *src_width2,
		ms_real *bscat_out)
{
  ms_real drange = fabs(range[2]-range[1]);

  int nt = 2*m;
  int it;
  int i;
  int ibscat;
  /*
  for (i = 0; i < n; i++) fprintf(stderr, "*** %g %g %g %g %g %g\n",
				  ext[i], ssa[i], g[i], src_power_in[i],
				  src_power_out[i], src_width2[i]);
  */
  /* Allocate and set-to-zero the intermediate arrays */
  if (ms2_init_intermediate_arrays(n) == MS_FAILURE) {
    fprintf(stderr, "Error allocating arrays at line %d of %s\n", __LINE__, __FILE__);
    return MS_FAILURE;
  }
  
  /* Calculate transfer coefficients */
  if (ms_options & MS_SIMPLE_2S_COEFFTS) {
    ms2_calculate_deltas_simple(n, ext, ssa, g, drange);
  }
  else {
    ms2_calculate_deltas(n, ext, ssa, g, drange);
  }

  ms2_total_src = 0.0;
  ms2_total_reflected = 0.0;

  /* Loop through each timestep */
  for (it = 0; it < nt; it++) {
    ms_real *tmp_I;
    ms_real expansion;
    /* Work out how many spatial points to calculate given that we
       don't want to waste time simulating regions not yet reached by
       the outgoing beam, or regions that can't scatter back to the
       receiver within the time period of interest */
    int max_i = it;
    if (max_i >= n) {
      max_i = n-1;
    }
    /* If the internal radiances and variances are to be output,
       then we calculate even in regions that will not scatter
       back to the receiver within the sample time. */
    if (!(ms_options & MS_PROPAGATION_TO_STDERR) && (it > nt-n)) {
      max_i = nt-it;
    }

    ms2_total_reflected += ms2_delta1[0]*ms2_Iin[0];

    /* Loop through each range gate */
    for (i = 0; i <= max_i ; i++) {
      ms_real footprint_radius2 = instrument.rho_receiver*instrument.rho_receiver
	*(range[i]-instrument.altitude)*(range[i]-instrument.altitude);

      /* Step the photon energy forward in time */
      ms2_Iin_next[i]
	= ms2_Iin[i]   * ms2_delta0[i]
	+ ms2_Iout[i]  * ms2_delta1[i]
	+ ms2_Iin[i+1] * ms2_delta2[i+1]
	+ ms2_Iout[i-1]* ms2_delta3[i-1]
	+ ms2_Iin[i-1] * ms2_delta4[i-1]
	+ ms2_Iout[i+1]* ms2_delta5[i+1];
      ms2_Iout_next[i]
	= ms2_Iout[i]  * ms2_delta0[i]
	+ ms2_Iin[i]   * ms2_delta1[i]
	+ ms2_Iout[i-1]* ms2_delta2[i-1]
	+ ms2_Iin[i+1] * ms2_delta3[i+1]
	+ ms2_Iout[i+1]* ms2_delta4[i+1]
	+ ms2_Iin[i-1] * ms2_delta5[i-1];
      if (ms2_Iin_next[i] < 0.0) {
	fprintf(stderr, "Warning: negative radiance at line %d of %s, timestep %d gate %d\n"
		"   (Iin_next=%g Iin=%g Iout=%g delta0=%g delta1=%g delta2=%g)\n",
		__LINE__, __FILE__, it, i,
		ms2_Iin_next[i], ms2_Iin[i], ms2_Iout[i],
		ms2_delta0[i], ms2_delta1[i+1], ms2_delta2[i]);
      }

      /* Step the variance forward in time */
      //#define USE_SLOW_EXPANSION 1
#ifdef USE_SLOW_EXPANSION
      expansion = ms2_get_expansion(drange, ms2_transport_mfp[i], src_width2[i],
				    ms2_Iin[i], ms2_Vin[i]);
#else
      expansion = ms2_get_expansion_fast(drange, ms2_transport_mfp[i],
					 src_width2[i],
					 ms2_Iin[i], ms2_Vin[i]);
#endif
      ms2_Vin_next[i]
	= ms2_Vin[i]   * ms2_delta0[i]
	+ ms2_Vout[i]  * ms2_delta1[i]
	+ ms2_Vin[i+1] * ms2_delta2[i+1]
	+ ms2_Vout[i-1]* ms2_delta3[i-1]
	+ ms2_Vin[i-1] * ms2_delta4[i-1]
	+ ms2_Vout[i+1]* ms2_delta5[i+1]
	+ ms2_Iin[i]   * expansion;
#ifdef USE_SLOW_EXPANSION
      expansion = ms2_get_expansion(drange, ms2_transport_mfp[i], src_width2[i],
				    ms2_Iout[i], ms2_Vout[i]);
#else
      expansion = ms2_get_expansion_fast(drange, ms2_transport_mfp[i],
					 src_width2[i],
					 ms2_Iout[i], ms2_Vout[i]);
#endif
      ms2_Vout_next[i]
	= ms2_Vout[i]  * ms2_delta0[i]
	+ ms2_Vin[i]   * ms2_delta1[i]
	+ ms2_Vout[i-1]* ms2_delta2[i-1]
	+ ms2_Vin[i+1] * ms2_delta3[i+1]
	+ ms2_Vout[i+1]* ms2_delta4[i+1]
	+ ms2_Vin[i-1] * ms2_delta5[i-1]
	+ ms2_Iout[i]   * expansion;

      /* Increment the apparent backscatter */
      ibscat = (it+i)/2; // BEST FOR I3RC
      //      ibscat = (it+i-1)/2; // BEST FOR RADAR SCENARIO 3
      if (ms2_Vin_next[i] > 0.0 && ms2_Vout_next[i] > 0.0) {
	if (instrument.receiver_type == TOP_HAT) {
	  if (g[i] >= 1.0/(3.0*MS_MU1)) {
	    bscat_out[ibscat] += ms2_transmittance[i]
	      *ONE_OVER_FOUR_PI
	      *(ms2_Iin_next[i] * ssa[i]*ext[i]*2.0
		*(1.0-exp(-(footprint_radius2*ms2_Iin_next[i]/ms2_Vin_next[i]))));
	  }
	  else {
	    bscat_out[ibscat] += ms2_transmittance[i]
	      *ONE_OVER_FOUR_PI
	      *(ms2_Iin_next[i] * ssa[i]*ext[i]*(1.0+3.0*g[i]*MS_MU1)
		*(1.0-exp(-(footprint_radius2*ms2_Iin_next[i]/ms2_Vin_next[i])))
		+ms2_Iout_next[i] * ssa[i]*ext[i]*(1.0-3.0*g[i]*MS_MU1)
		*(1.0-exp(-(footprint_radius2*ms2_Iout_next[i]/ms2_Vout_next[i]))));
	  }
	}
	else {
	  if (g[i] >= 1.0/(3.0*MS_MU1)) {
	    bscat_out[ibscat] += ms2_transmittance[i]
	      *ONE_OVER_FOUR_PI
	      *(ms2_Iin_next[i] * ssa[i]*ext[i]*2.0
		/(1.0+ms2_Vin_next[i]/(ms2_Iin_next[i]*footprint_radius2)));
	  }
	  else {
	    bscat_out[ibscat] += ms2_transmittance[i]
	      *ONE_OVER_FOUR_PI
	      *(ms2_Iin_next[i] * ssa[i]*ext[i]*(1.0+3.0*g[i]*MS_MU1)
		/(1.0+ms2_Vin_next[i]/(ms2_Iin_next[i]*footprint_radius2))
		+ms2_Iout_next[i] * ssa[i]*ext[i]*(1.0-3.0*g[i]*MS_MU1)
		/(1.0+ms2_Vout_next[i]/(ms2_Iout_next[i]*footprint_radius2)));
	  }
	}
      }
    }
    
    /* Print propagation variables (radiances and variances) to standard error */
    if (ms_options & MS_PROPAGATION_TO_STDERR) {
      for (i = 1; i < n ; i++) {
	//      for (i = 0; i < n ; i++) {
	if (it < n && i == it) {
	  fprintf(stderr, "%d %d %g %g %g %g %g %g %g %g\n", it, i,
		  ms2_Iout_next[i], ms2_Iin_next[i],
		  ms2_Vout_next[i], ms2_Vin_next[i],
		  src_power_out[it], src_power_in[it],
		  src_power_out[it]*src_width2[it],
		  src_power_in[it]*src_width2[it]);
	}
	else {
	  fprintf(stderr, "%d %d %g %g %g %g 0 0 0 0\n", it, i,
		  ms2_Iout_next[i], ms2_Iin_next[i],
		  ms2_Vout_next[i], ms2_Vin_next[i]);
	}
      }
    }

    /* Add the incoming source power if we are in the first half of
       the time simulated */
    if (it < n) {
      /* The source power is split into that coming in towards the
	 instrument and that travelling out */
      if (src_power_in[it] < 0.0 || src_power_out[it] < 0.0) {
	fprintf(stderr, "Error: negative source terms for two-stream equations at line %d of %s\n"
		        "       (src_power_out[%d]=%g src_power_in[%d]=%g ssa=%g g=%g)\n",
		__LINE__, __FILE__,
		it, src_power_out[it], it, src_power_in[it], ssa[it], g[it]);
	return MS_FAILURE;
      }
      else if (src_width2[it] < 0.0) {
	fprintf(stderr, "Error: negative source width for two-stream equations at line %d of %s\n",
		__LINE__, __FILE__);
	return MS_FAILURE;
      }
      ms2_Iin_next[it] += src_power_in[it];
      ms2_Iout_next[it] += src_power_out[it];
      ms2_Vin_next[it] += src_power_in[it] * src_width2[it];
      ms2_Vout_next[it] += src_power_out[it] * src_width2[it];
      ms2_total_src += src_power_in[it] + src_power_out[it];
    }

#define swap_I(I, I_next) tmp_I=I; I=I_next; I_next=tmp_I;
    swap_I(ms2_Iin, ms2_Iin_next);
    swap_I(ms2_Iout, ms2_Iout_next);
    swap_I(ms2_Vin, ms2_Vin_next);
    swap_I(ms2_Vout, ms2_Vout_next);
  }
  return MS_SUCCESS;
}
