#!/bin/bash


if [ ! "$1" ]
then
    FILE=benchmark_profile100.in
    echo Using $FILE
else
    FILE=$1
fi

echo "*** O(N) QSA model (10000 iterations)"

time ./multiscatter -qsa-only -fast-qsa -repeat 10000 -quiet < $FILE > /dev/null

echo
echo
echo "*** O(N^2) QSA model (Hogan 2006) (1000 iterations)"

time ./multiscatter -qsa-only -repeat 1000 -quiet < $FILE > /dev/null

echo
echo
echo "*** Wide angle plus O(N) QSA models (100 iterations)"

time ./multiscatter -fast-qsa -repeat 100 -no-forward-lobe -quiet < $FILE > /dev/null

echo
echo
echo "*** Explicit model 2nd order (1000 iterations)" 

time ./multiscatter -explicit 2 -qsa-only -repeat 1000 -quiet < $FILE > /dev/null

echo
echo
echo "*** Explicit model 3rd order (100 iterations)" 

time ./multiscatter -explicit 3 -qsa-only -repeat 100 -quiet < $FILE > /dev/null

echo
echo
echo "*** Explicit model 4rd order (10 iterations)" 

time ./multiscatter -explicit 4 -qsa-only -repeat 10 -quiet < $FILE > /dev/null

echo
echo
echo "*** Explicit model 5rd order (2 iterations)" 

time ./multiscatter -explicit 5 -qsa-only -repeat 10 -quiet < $FILE > /dev/null


#[1.227 1.865 1.619 1.248 4.215 10.977]./[10000 1000 100 1000 100 10]
#[0.621 0.494 0.414 0.330 0.570 0.768]./[10000 1000 100 1000 100 10]
