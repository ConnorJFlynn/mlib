/* multiscatter.h -- Calculation of lidar and radar multiple scattering 

   Copyright (C) 2004-2007 Robin Hogan <r.j.hogan@reading.ac.uk>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


   This is the header file for an algorithm for efficient calculation
   of the lidar or radar backscatter profile in the presence of
   multiple scattering.  Several different algorithms are available
   depending on the multiple scattering regime.  For quasi-small-angle
   multiple scattering, Eloranta's formulation for double scattering
   is employed but with a multi-moment parameterisation of the photon
   distribution for estimating scattering at higher orders that
   ensures O(N^2) efficiency where N is the number of range gates
   (Hogan 2006, Applied Optics). For wide-angle multiple scattering an
   approach based on the time-dependent two-stream equations is used.
*/

#ifndef _MULTISCATTER_H
#define _MULTISCATTER_H 1

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

#define MS_PI 3.14159265358979323846

/* The code may be compiled either in single or double
   precision. Double precision is the default but may be overridden by
   compiling with "-DSINGLE_PRECISION". */
#ifdef SINGLE_PRECISION
typedef float ms_real;
#else
typedef double ms_real;
#endif

/* External functions return an integer with one of these values */
#define MS_SUCCESS 0
#define MS_FAILURE 1

/* Bitwise options */
#define MS_QUIET (1L<<0)
#define MS_QSA_ONLY (1L<<1)
#define MS_SIMPLE_OPTICAL_DEPTH (1L<<2)
#define MS_CRUDE_OPTICAL_DEPTH (1L<<3)
#define MS_CRUDE_INTEGRATION (1L<<4)
#define MS_NO_MULTISCAT_WITHIN_GATE (1L<<5)
#define MS_DOUBLE_SCATTERING_ONLY (1L<<6)
#define MS_CRUDE_DOUBLE_SCATTERING (1L<<7)
#define MS_NUMERICAL_JACOBIAN (1L<<8)
#define MS_NO_MOLECULAR_EXTINCTION (1L<<9)
#define MS_WIDE_ANGLE_CUTOFF (1L<<10)
#define MS_APPROXIMATE_EXPONENTIAL (1L<<11)
#define MS_NO_FORWARD_LOBE (1L<<12)
#define MS_SSA_SCALES_FORWARD_LOBE (1L<<13)
#define MS_SIMPLE_2S_COEFFTS (1L<<14)
#define MS_PROPAGATION_TO_STDERR (1L<<15)
#define MS_EXPLICIT_QSA (1L<<16)
#define MS_OUTPUT_BSCATS (1L<<17)
#define MS_OUTPUT_DISTRIBUTION (1L<<18)
#define MS_FAST_QSA (1L<<19)
#define MS_QSA_LAG (1L<<20)

/* This is from diffusion theory and should not be changed */
#define MS_D_FACTOR 1.33333333
#define MS_ONE_OVER_D_FACTOR 0.75

/* The two-stream cosine-zenith angle */
#define MS_MU1 0.5

/* Factors parameterizing the shape of the droplet phase function near
   backscatter */
#define MS_MIE_U1 0.3
#define MS_MIE_U2 0.5
#define MS_MIE_V1_SQD 16.0
#define MS_MIE_V2_SQD 0.16
/* Factors parameterizing the shape of the droplet phase function near
   backscatter */
#define MS_YANG_W 0.89
#define MS_YANG_GAMMA0 0.038

/* After calling multiscatter_qsa(), the following variables are
   available to be accessed - see multiscatter_qsa.c for details. */
extern ms_real *ms_E_once;           /* dimensionless */
extern ms_real *ms_Emu2_once;        /* radians^2 */
extern ms_real *ms_E_multi;          /* dimensionless */
extern ms_real *ms_Emu2_multi;       /* radians^2 */
extern ms_real *ms_Pmu2_once;        /* radians^2 */
extern ms_real *ms_Pmu2_multi;       /* radians^2 */
extern ms_real *ms_EPcov_once;       /* radians^2 */
extern ms_real *ms_EPcov_multi;      /* radians^2 */
extern ms_real *ms_bscat_single;     /* m-1 sr-1 */
extern ms_real *ms_bscat_double;     /* m-1 sr-1 */
extern ms_real *ms_bscat_multi;      /* m-1 sr-1 */
extern ms_real *ms_bscat_air_single; /* m-1 sr-1 */
extern ms_real *ms_bscat_air_double; /* m-1 sr-1 */
extern ms_real *ms_bscat_air_multi;  /* m-1 sr-1 */

extern ms_real *ms_qsa_lag; /* m */

extern int ms_options;
extern int ms_max_scattering_order;
extern ms_real ms_max_theta;

/* Surface properties; note that at present these are not used, but
   the plan is to incorporate single and multiple scatterng from the
   surface */
typedef struct {
  ms_real sigma0;
  ms_real diffuse_albedo;
  ms_real direct_to_diffuse_albedo;
  ms_real diffuse_to_direct_backscatter;
  ms_real range; /* This might implicitly be at 0 or at the far end
		    of the ray... */
} ms_surface;

/* Different receiver types */
typedef enum {
  TOP_HAT = 0,
  GAUSSIAN = 1
} ms_receiver_type;

/* Properties of the instrument */
typedef struct {
  ms_receiver_type receiver_type;
  ms_real altitude;
  ms_real wavelength;
  ms_real rho_transmitter; /* transmitter_half-angle divergence;*/
  ms_real rho_receiver;    /* reciever half-angle field-of-view;*/
} ms_instrument;

/* Functions to allocate and zero or to free intermediate
   arrays. External programs need not call these functions.*/
int ms_init_intermediate_arrays(int ngates);
void ms_free_intermediate_arrays();

/* Functions to change the algorithm options */
void ms_set_options(int options);
void ms_add_options(int options);

/* The quasi-small-angle multiple scattering algorithm is called using
   this function. MS_FAILURE is returned if there was a problem
   allocating the memory for the intermediate arrays, MS_SUCCESS
   otherwise. */
int multiscatter_qsa(
    /* Input data */
    int n,                    /* Number of range gates in profile */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *radius,          /* Cloud/aerosol equivalent radius, microns */
    ms_real *ext,             /* Cloud/aerosol extinction coefficient, m-1 */
    ms_real *ext_bscat_ratio, /* Cloud/aerosol ext./backscatter ratio, sr */
    ms_real *ext_air,         /* Air ext. coefft, m-1 (NULL for vacuum) */
    ms_real *bscat_peak_factor, /* Relative amplitude of P(180), 0-1 */
    ms_real *bscat_peak_width,  /* Width of peak near 180, radians */
    /* Output data */
    ms_real *bscat_out        /* Measured backscatter, m-1 sr-1 */
    );

/* The fast quasi-small-angle multiple scattering algorithm is called
   using this function. MS_FAILURE is returned if there was a problem
   allocating the memory for the intermediate arrays, MS_SUCCESS
   otherwise. */
int multiscatter_fastqsa(
    /* Input data */
    int n,                    /* Number of range gates in profile */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *radius,          /* Cloud/aerosol equivalent radius, microns */
    ms_real *ext,             /* Cloud/aerosol extinction coefficient, m-1 */
    ms_real *ext_bscat_ratio, /* Cloud/aerosol ext./backscatter ratio, sr */
    ms_real *ext_air,         /* Air ext. coefft, m-1 (NULL for vacuum) */
    ms_real *droplet_fraction,/* Fraction of ext due to droplets, 0-1 */
    ms_real *ice_fraction,    /* ...due to pristine ice with Yang-like phase function */
    /* Output data */
    ms_real *bscat_out        /* Measured backscatter, m-1 sr-1 */
    );

/* As multiscatter_fastqsa but with a pulse lag calculation */
int multiscatter_fastqsa_lag(
    /* Input data */
    int n,                    /* Number of range gates in profile */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *radius,          /* Cloud/aerosol equivalent radius, microns */
    ms_real *ext,             /* Cloud/aerosol extinction coefficient, m-1 */
    ms_real *ext_bscat_ratio, /* Cloud/aerosol ext./backscatter ratio, sr */
    ms_real *ext_air,         /* Air ext. coefft, m-1 (NULL for vacuum) */
    ms_real *droplet_fraction,/* Fraction of ext due to droplets, 0-1 */
    ms_real *ice_fraction,    /* ...due to pristine ice with Yang-like phase function */
    /* Output data */
    ms_real *bscat_out,       /* Measured backscatter, m-1 sr-1 */
    ms_real *lag_out          /* Pulse lag, m */
    );

/* A version of Eloranta's (1998) quasi-small-angle multiple
   scattering algorithm but using the PVC methodology, taken to
   "norder" orders of scattering */
int ms_set_max_scattering_order(int norder);
int multiscatter_explicit(int n,
			  ms_instrument instrument, ms_surface surface,
			  ms_real *range, ms_real *radius,
			  ms_real *ext, ms_real *ext_bscat_ratio,
			  ms_real *ext_air, ms_real *ssa_air,
			  ms_real *bscat_out);

/* Return the total normalized energy that has been input to the
   two-stream scheme via the source terms, and the total reflected
   energy */
int ms2_get_stats(ms_real *total_src, ms_real *total_reflected);

/* As above but including the single-scattering multiplier */
int ms_get_stats(ms_real *total_src, ms_real *total_reflected,
		 ms_real *ss_multiplier);

/* Prints statistics to the specified stream */
int ms_print_stats(FILE *file);

/* Perform the time-dependent two-stream calculation for wide-angle
   multiple scattering, and add the result to bscat_out */
int multiscatter_2s(
    /* Input data */
    int n,                    /* Number of input gates */
    int m,                    /* Number of output gates (>= n) */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *ext,             /* Total extinction coefficient, m-1 */
    ms_real *ssa,             /* Total single-scatter albedo */
    ms_real *g,               /* Total asymmetry factor */
    ms_real *src_in,          /* Source function power: inwards */
    ms_real *src_out,         /* Source function power: outwards */
    ms_real *src_width2,      /* 1/e source function width^2, radians^2 */
    /* Output data */
    ms_real *bscat_out        /* Measured backscatter, m-1 sr-1 */
    );

/* Perform the multiple scattering calculation, using which ever
   combination of algorithms is appropriate depending on multiple
   scattering regime */
int multiscatter(
    /* Input data */
    int n,                    /* Number of input gates */
    int m,                    /* Number of output gates (>= n) */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *radius,          /* Cloud/aerosol equivalent radius, microns */
    ms_real *ext,             /* Total extinction coefficient, m-1 */
    ms_real *ssa,             /* Total single-scatter albedo */
    ms_real *g,               /* Total asymmetry factor */
    ms_real *ext_bscat_ratio, /* Cloud/aerosol ext./backscatter ratio, sr */
    ms_real *ext_air,         /* Air ext. coefft, m-1 (NULL for vacuum) */
    ms_real *ssa_air,
    ms_real *bscat_peak_factor, /* Relative amplitude of P(180), 0-1 */
    ms_real *bscat_peak_width,  /* Width of peak near 180, radians */
    /* Output data */
    ms_real *bscat_out        /* Measured backscatter, m-1 sr-1 */
    );

/* Quasi-small-angle multiple scattering calculation including
   returning the Jacobian */
int multiscatter_jacobian(
    /* Input data */
    int n,                    /* Number of range gates in profile */
    int m,                    /* Number of output gates (>= n) */
    ms_instrument instrument, /* Structure containing instrument variables */
    ms_surface surface,       /* Surface scattering variables */
    ms_real *range,           /* Height of each range gate, metres */
    ms_real *radius,          /* Cloud/aerosol equivalent radius, microns */
    ms_real *ext,             /* Cloud/aerosol extinction coefficient, m-1 */
    ms_real *ssa,             /* Total single-scatter albedo */
    ms_real *g,               /* Total asymmetry factor */
    ms_real *ext_bscat_ratio, /* Cloud/aerosol ext./backscatter ratio, sr */
    ms_real *ext_air,         /* Air ext. coefft, m-1 (NULL for vacuum) */
    ms_real *ssa_air,
    ms_real *bscat_peak_factor, /* Relative amplitude of P(180), 0-1 */
    ms_real *bscat_peak_width,  /* Width of peak near 180, radians */
    int n_x, /* Number of state variables to compute the Jacobian of */
    int n_y, /* Number of measurements to compute the Jacobian of */
    int *i_x, /* Index to the required state variables */
    int *i_y, /* Index to the required measurements */
    /* Output data */
    ms_real *bscat_out,        /* Measured backscatter, m-1 sr-1 */
    ms_real **d_ln_bscat_d_ln_ext, /* Jacobian with respect to ln(extinction) */
    ms_real **d_ln_bscat_d_ln_radius, /* Jacobian w.r.t. ln(radius) */
    ms_real *d_ln_bscat_d_ln_ext_bscat_ratio /* ...w.r.t. ln(ext_bscat_ratio) */
    );

/* Calculate the scaling factor to account for anisotropic
   near-backscatter phase functions */
ms_real anisotropic_factor(
	   ms_real width2,          /* spatial variance (m2) */
	   ms_real zeta2,           /* angular variance (rad2) */
	   ms_real cov,             /* covariance (m rad) */
	   ms_real Theta2,          /* forward lobe variance (rad2) */
	   ms_real range,           /* range from instrument (m) */
	   ms_real width2_max,      /* receiver field-of-view variance (m2) */
	   ms_real ext,             /* Cloud extinction coefficient (m-1) */
	   ms_real ext_air,         /* Air extinction coefficient (m-1) */
	   ms_real droplet_fraction,/* Fraction of ext due to droplets */
	   ms_real ice_fraction     /* Fraction of ext due to pristine ice */
	   );


/* Calculate the spatial variance of the quasi-direct outgoing beam of
   photons using an O(N) efficient algorithm */
int ms_variance(int n, ms_real wavelength, ms_real rho_laser,
		ms_real lidar_altitude, ms_real *range, ms_real *radius,
		ms_real *ext, ms_real *variance_out);


int msd_set_distribution_resolution(int num_x, ms_real dx);
int msd_init_intermediate_arrays(int num_gates);
int msd_increment_distribution(int order, int gate, 
			       ms_real energy, ms_real variance);
int msd_print_distribution(FILE* file);

#ifdef __cplusplus
}
#endif

#endif
