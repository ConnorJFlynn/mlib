/* variance.c -- Fast calculation of the lateral variance of outgoing photons

   Copyright (C) 2006 Robin Hogan <r.j.hogan@reading.ac.uk> 

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


   The algorithm is implemented in ANSI C, but a Fortran interface is
   provided.
*/

#include <math.h>
#include "multiscatter.h"

/* Calculate the lateral variance of the outgoing unscattered and
   forward-scattered photon distribution */
int
ms_variance(int n, ms_real wavelength, ms_real rho_laser,
	    ms_real inst_altitude, ms_real *range, ms_real *radius,
	    ms_real *ext, ms_real *variance_out)
{
  ms_real drange = fabs(range[2]-range[1]);
  ms_real drange2 = drange*drange;
  ms_real angle_var = rho_laser*rho_laser;
  ms_real pos_var = variance_out[0]
    = (range[0]-inst_altitude)*(range[0]-inst_altitude)*angle_var;
  ms_real covar = fabs(range[0]-inst_altitude)*angle_var;

  int i;
  for (i = 0; i < n-1; i++) {
    ms_real theta = wavelength/(MS_PI*radius[i]);
    pos_var += angle_var*drange2 + covar*drange;
    covar += angle_var*drange;
    angle_var += 0.5*ext[i]*theta*theta*drange;
    variance_out[i+1] = pos_var;
  }
  return MS_SUCCESS;
}

