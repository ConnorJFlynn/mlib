/* main.c -- Single-profile interface for lidar multiple scattering
   algorithm

   Copyright (C) 2004-2007 Robin Hogan <r.j.hogan@reading.ac.uk> 

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


   Run "./multiscatter -help" to get usage information.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "multiscatter.h"
#include "version.h"

#define MAX_GATES 10000
#define MAX_CHARS 128

#ifdef SINGLE_PRECISION
#define READ_HEADER_FORMAT "%d %g %g %g %g\n"
#define READ_FORMAT "%g %g %g %g %g %g %g %g %g %g\n"
#else
#define READ_HEADER_FORMAT "%d %lg %lg %lg %lg\n"
#define READ_FORMAT "%lg %lg %lg %lg %lg %lg %lg %lg %lg %lg\n"
#endif

#define CHECK(function) if ((status = (function))) { fprintf(stderr, \
   "Error at line %d of %s: code %d\n", __LINE__, __FILE__, status); exit(status); }

/* Print usage information */
void
usage(char *exec_name)
{
  fprintf(stderr,
	  "Usage\n"
	  "  %s [options] data_in.dat > data_out.dat\n"
	  "  %s [options] < data_in.dat > data_out.dat\n"
	  "\n", exec_name, exec_name);
  fprintf(stderr, 
	  "General options\n" 
	  "  -help           Display this message\n"
	  "  -repeat n       Repeat algorithm n times (for benchmarking)\n"
	  "  -quiet          Don't report activity to stderr\n"
	  "  -gaussian-receiver\n"
	  "                  Receiver is Gaussian rather than top-hat shaped\n"
	  "  -numerical-jacobian\n"
	  "                  Output the Jacobian calculated (slowly) using finite\n"
	  "                  differences\n"
	  "\n");
  fprintf(stderr,
	  "Options for quasi-small-angle (QSA) multiple scattering calculation\n"
	  "  -qsa-only       Don't perform wide-angle multiple-scattering calculation\n"
	  "  -explicit n     Use an explicit model with n orders of scattering\n"
	  "  -fast-qsa       Use fast O(N) QSA model\n"
	  "  -lag            Calculate QSA lag (m)\n"
	  "  -simple-optical-depth\n"
	  "                  Use simple optical depth integration\n"
	  "  -crude-optical-depth\n"
	  "                  Use crude optical depth integration\n"
	  "  -crude-integration\n"
	  "                  Use crude double/multiple scattering integration\n");
  fprintf(stderr,
	  "  -no-multiscat-within-gate\n"
	  "                  Photon cannot be forward scattered more than once within a\n"
	  "                  single gate; note that this has the opposite effect to\n"
	  "                  \"-crude-integration\"\n"
	  "  -double-scattering-only\n"
	  "                  Don't include triple and higher-order scatterings\n");
  fprintf(stderr,
	  "  -no-molecular-extinction\n"
	  "                  Molecules do not extinguish the beam\n"
	  "  -wide-angle-cutoff <theta>\n"
	  "                  Forward scattering at angles greater than <theta> radians\n"
	  "                  are deemed to escape, a crude way to deal with a problem\n"
	  "                  associated with aerosols\n");
  fprintf(stderr,
	  "  -crude-double-scattering\n"
	  "                  Don't use Eloranta's slow but accurate double scattering\n"
	  "                  formulation\n"
	  "  -approx-exp     Appriximate the exp() function call for speed\n"
	  "  -jacobian       Output the approximate but fast Jacobian\n");
  fprintf(stderr,
	  "  -output-bscats  Also output 6 individual backscatter components\n"
	  "  -output-all     Also output 8 internal variables at each gate\n"
	  "  -output-distribution n dx\n"
	  "                  Output horizontal photon distributions at n points spaced\n"
	  "                  dx apart, starting at dx/2\n"
	  "\n");
  fprintf(stderr,
	  "Options for wide-angle multiple-scattering\n"
	  "  -no-forward-lobe\n"
	  "                  Radar-like phase function behaviour: use single-scattering\n"
	  "                  rather than QSA\n"
	  "  -simple-2s-coeffts\n"
	  "                  Use the simple upwind Euler formulation (can be unstable\n"
	  "                  for high optical depth)\n");
  fprintf(stderr,
	  "  -ssa-scales-forward-lobe\n"
	  "                  Single-scattering albedo less than unity reduces the\n"
	  "                  forward scattering lobe as well as wide-angle scattering\n"
	  "  -num-samples m  Output m samples, allowing sampling of signals appearing\n"
	  "                  to originate below ground\n"
	  "  -propagation-to-stderr\n"
	  "                  Print the diffuse photon energies and variances to\n"
	  "                  standard error\n"
	  "\n");
  fprintf(stderr,
	  "Input data\n"
	  "  First line: 5 values\n"
	  "    1: Number of range gates in profile\n"
	  "    2: Lidar wavelength (m)\n"
	  "    3: Laser divergence, 1/e half-width (radians)\n"
	  "    4: Telescope field-of-view, half-width (radians)\n"
	  "    5: Altitude of lidar (m)\n");
  fprintf(stderr,
	  "  Subsequent lines: 4, 5, 8 or 10 values (all 8 required for the wide-angle\n"
	  "  calculation; all 10 to represent anisotropic phase functions near 180 deg)\n"
	  "    1: Range of gate above ground starting with nearest gate to lidar (m)\n"
	  "    2: Extinction coefficient of cloud/aerosol only (m-1)\n"
	  "    3: Equivalent-area cloud/aerosol radius (m)\n"
	  "    4: Extinction-to-backscatter ratio of cloud/aerosol (sr)\n"
	  "    5: Air extinction coefficient (m-1); optional (zero if missing)\n");
  fprintf(stderr,
	  "    6: Single scattering albedo of cloud/aerosol\n"
	  "    7: Scattering asymmetry factor of cloud/aerosol\n"
	  "    8: Single scattering albedo of air\n");
  fprintf(stderr,
	  "    9: Fraction of cloud/aerosol backscatter due to droplets (real number\n"
	  "         between 0 and 1), for representing anisotropic near-180 phase\n"
	  "         functions in the QSA algorithm\n"
	  "   10: Pristine ice fraction, for anisotropic near-180 phase functions\n"
	  "         from Yang et al. (2000); note that irregular ice particles\n"
	  "         are believed to have isotropic near-180 phase functions, in\n"
	  "         which case set this variable to zero\n"
	  "\n");
  fprintf(stderr,
	  "Output data (without -jacobian or -numerical-jacobian option)\n"
	  "  Default: 5 values per range gate\n"
	  "    1: Index of range gate\n"
	  "    2: Apparent range above ground (m)\n"
	  "    3: Extinction coefficient (m-1)\n"
	  "    4: Equivalent-area particle radius (microns)\n"
	  "    5: Apparent backscatter, total (m-1 sr-1)\n");
  fprintf(stderr,
	  "  With the \"-output-bscats\" option, output an additional 6 QSA values\n"
	  "    6: Apparent backscatter, single scattering cloud/aerosol only (m-1 sr-1)\n"
	  "    7: Apparent backscatter, double scattering cloud/aerosol only (m-1 sr-1)\n"
	  "    8: Apparent backscatter, triple+ scattering cloud/aerosol (m-1 sr-1)\n"
	  "    9: Apparent backscatter, single scattering air only (m-1 sr-1)\n"
	  "   10: Apparent backscatter, double scattering air only (m-1 sr-1)\n"
	  "   11: Apparent backscatter, triple+ scattering air only (m-1 sr-1)\n");
  fprintf(stderr,
	  "  With the \"-output-all\" option, output an additional 8 QSA values\n"
	  "   12: Es, singly forward scattered energy coefficient\n"
	  "   13: Em, multiply forward scattered energy coefficient\n"
	  "   14: lateral std-dev of outgoing singly forward scattered photons (m)\n"
	  "   15: lateral std-dev of outgoing multply forward scattered photons (m)\n");
  fprintf(stderr,
	  "   16: std-dev of singly forward scattered photon direction (radians)\n"
	  "   17: std-dev of multiply forward scattered photon direction (radians)\n"
	  "   18: corr-coefft of singly scattered photon angular position and direction\n"
	  "   19: corr-coefft of multiply scattered photon angular pos and direction\n"
	  "\n");
  fprintf(stderr,
	  "Output data (with -jacobian or -numerical-jacobian option)\n"
	  "   n x n matrix: d(ln atten. backscatter) / d(ln extinction coefficient)\n"
	  "   n x n matrix: d(ln atten. backscatter) / d(ln particle radius)\n"
	  "   1 x n vector: d(ln atten. backscatter) / d(ln ext-to-bscat ratio)\n");
}

/* Main program */
int
main(int argc, char **argv)
{
  FILE *infile = stdin;
  int n, m = 0, i, iarg;
  int nrepeats = 1;
  int output_all = 0;
  int output_jacobian = 0;
  int use_isotropic_pp = 0;
  int use_air_ext = 1;
  int print_stats = 0;
  int ninputs;
  int norder = 4;
  char buffer[MAX_CHARS];
  int options = 0;
  int ch, status;

  /* Ought to dynamically allocate these */
  ms_real range[MAX_GATES], radius[MAX_GATES],
    ext[MAX_GATES], ext_bscat_ratio[MAX_GATES], ext_air[MAX_GATES],
    bscat[MAX_GATES],
    droplet_fraction[MAX_GATES], pristine_ice_fraction[MAX_GATES];
  ms_real ssa[MAX_GATES], g[MAX_GATES], ssa_air[MAX_GATES];

  ms_instrument instrument = {TOP_HAT, 0.0, 1.0, 1.0, 1.0};
  ms_surface surface = {0.0, 0.0, 0.0, 0.0, 0.0};

  /* Handle command-line arguments */
  for (iarg = 1; iarg < argc; ++iarg) {
    if (strcmp(argv[iarg], "-qsa-only") == 0) {
      /* Only use quasi-small-angle calculation */
      options |= MS_QSA_ONLY;
    }
    else if (strcmp(argv[iarg], "-fast-qsa") == 0) {
      /* Use fast O(N) quasi-small-angle calculation */
      options |= MS_FAST_QSA;
    }
    else if (strcmp(argv[iarg], "-lag") == 0) {
      /* Use fast O(N) quasi-small-angle calculation with lag
	 calculation */
      options |= MS_FAST_QSA;
      options |= MS_QSA_LAG;
    }
    else if (strcmp(argv[iarg], "-output-bscats") == 0) {
      /* Output different backscatters */
      options |= MS_OUTPUT_BSCATS;
    }
    else if (strcmp(argv[iarg], "-output-all") == 0) {
      /* Output all internal variables */
      options |= MS_OUTPUT_BSCATS;
      output_all = 1;
    }
    else if (strcmp(argv[iarg], "-output-distribution") ==0) {
      int n;
      ms_real dx;
      if (argc > ++iarg) {
	n = atoi(argv[iarg]);
	if (n < 1) {
	  fprintf(stderr,
		  "Error: number of distribution points must be greater than 0\n");
	  exit(1);
	}
	if (argc > ++iarg) {
	  dx = atof(argv[iarg]);
	  if (dx < 0.0) {
	    fprintf(stderr,
		    "Error: distribution point spacing must be greater than 0.0\n");
	    exit(1);
	  }
	  else {
	    options |= MS_OUTPUT_DISTRIBUTION;
	    msd_set_distribution_resolution(n, dx);
	  }
	}
	else {
	  fprintf(stderr, "Error: distribution point spacing (dx) not specified\n");
	  exit(1);
	}
      }
      else {
	fprintf(stderr, "Error: number of distribution points not specified\n");
	exit(1);
      }
    }
    else if (strcmp(argv[iarg], "-print-stats") == 0) {
      /* Print statistics */
      print_stats = 1;
    }
    else if (strcmp(argv[iarg], "-gaussian-receiver") == 0) {
      /* Use radar-like Gaussian receiver pattern rather than
	 top-hat */
      //      options |= MS_GAUSSIAN_RECEIVER;
      instrument.receiver_type = GAUSSIAN;
    }
    else if (strcmp(argv[iarg], "-no-forward-lobe") == 0) {
      /* Use radar-like phase function behaviour: no narrow forward
	 lobe */
      options |= MS_NO_FORWARD_LOBE;
    }
    else if (strcmp(argv[iarg], "-ssa-scales-forward-lobe") == 0) {
      options |= MS_SSA_SCALES_FORWARD_LOBE;
    }
    else if (strcmp(argv[iarg], "-simple-2s-coeffts") == 0) {
      options |= MS_SIMPLE_2S_COEFFTS;
    }
    else if (strcmp(argv[iarg], "-simple-optical-depth") == 0) {
      /* Use simple optical depth calculation */
      options |= MS_SIMPLE_OPTICAL_DEPTH;
    }
    else if (strcmp(argv[iarg], "-crude-optical-depth") == 0) {
      /* Use crude optical depth calculation */
      options |= MS_CRUDE_OPTICAL_DEPTH;
    }
    else if (strcmp(argv[iarg], "-crude-integration") == 0) {
      /* Use crude integration for double and multiple scattering */
      options |= MS_CRUDE_INTEGRATION;
      options &= ~MS_NO_MULTISCAT_WITHIN_GATE;
    }
    else if (strcmp(argv[iarg], "-no-multiscat-within-gate") == 0) {
      /* Each photon cannot be forward scattered more than once within
	 a range gate */
      options |= MS_NO_MULTISCAT_WITHIN_GATE;
      options &= ~MS_CRUDE_INTEGRATION;
    }
    else if (strcmp(argv[iarg], "-no-molecular-extinction") == 0) {
      /* Molecules backscatter but don't extinguish */
      options |= MS_NO_MOLECULAR_EXTINCTION;
    }
    else if (strcmp(argv[iarg], "-crude-double-scattering") == 0) {
      /* Use crude but fast method for double scattering */
      options |= MS_CRUDE_DOUBLE_SCATTERING;
    }
    else if (strcmp(argv[iarg], "-approx-exp") == 0) {
      /* Use crude but very fast method for double scattering */
      options |= MS_APPROXIMATE_EXPONENTIAL;
    }
    else if (strcmp(argv[iarg], "-double-scattering-only") == 0) {
      /* Use crude but fast method for double scattering */
      options |= MS_DOUBLE_SCATTERING_ONLY;
    }
    else if (strcmp(argv[iarg], "-wide-angle-cutoff") == 0) {
      /* A crude method to cope with the problem of representing both
	 cloud and wide-angle-scattering aerosol in the same profile,
	 without running the full wide-angle scattering code */
      if (iarg + 1 < argc) {
	options |= MS_WIDE_ANGLE_CUTOFF;
	ms_max_theta = atof(argv[++iarg]);
      }
      else {
	fprintf(stderr, "Error: option \"-wide-angle-cutoff\" requires an angle to be specified\n");
	exit(1);
      }
    }
    else if (strcmp(argv[iarg], "-explicit") == 0) {
      if (iarg + 1 < argc) {
	norder = atoi(argv[++iarg]);
	options |= MS_EXPLICIT_QSA;
	if (ms_set_max_scattering_order(norder) == MS_FAILURE) {
	  fprintf(stderr, "Error: number of scattering orders in explicit calculation out of range\n");
	  exit(1);
	}
      }
      else {
	fprintf(stderr, "Error: option \"-explicit\" requires the number of scattering orders to be specified\n");
	exit(1);
      }
    }
    else if (strcmp(argv[iarg], "-jacobian") == 0) {
      /* Output the Jacobian */
      output_jacobian = 1;
    }
    else if (strcmp(argv[iarg], "-numerical-jacobian") == 0) {
      /* Output the Jacobian */
      output_jacobian = 1;
      options |= MS_NUMERICAL_JACOBIAN;
    }
    else if (strcmp(argv[iarg], "-propagation-to-stderr") == 0) {
      options |= MS_PROPAGATION_TO_STDERR;
      options |= MS_QUIET;
    }
    else if (strcmp(argv[iarg], "-repeat") == 0) {
      /* Perform repeat calculations for benchmarking purposes */
      if (argc > ++iarg) {
	nrepeats = atoi(argv[iarg]);
	if (nrepeats < 1 || nrepeats > 1000000) {
	  fprintf(stderr,
		  "Error: number of repeats must be between 1 and 1000000\n");
	  exit(1);
	}
      }
      else {
	fprintf(stderr, "Error: number of repeats not specified\n");
	exit(1);
      }
    }
    else if (strcmp(argv[iarg], "-num-samples") == 0) {
      if (argc > ++iarg) {
	m = atoi(argv[iarg]);
	if (m < 1 || m > MAX_GATES) {
	  fprintf(stderr,
		  "Error: number of instrument samples must be between 1 and 10000\n");
	  exit(1);
	}
      }
      else {
	fprintf(stderr, "Error: number of instrument samples not specified\n");
	exit(1);
      }      
    }
    else if (strcmp(argv[iarg], "-quiet") == 0) {
      options |= MS_QUIET;
    }
    else if (strcmp(argv[iarg], "-help") == 0) {
      usage(argv[0]);
      exit(1);
    }
    else if (argv[iarg][0] == '-') {
      /* Argument not understood */
      fprintf(stderr, "Error: \"%s\" not understood\n", argv[iarg]);
      usage(argv[0]);
      exit(0);
    }
    else {
      /* Assume the argument is a filename */
      if (! (infile = fopen(argv[iarg], "r"))) {
	fprintf(stderr, "Error: \"%s\" not found\n", argv[iarg]);
	exit(1);
      }
      break;
    }
  }

  /* Report activity */
  if (!(options & MS_QUIET)) {
    fprintf(stderr, "Multiscatter %s\n", MS_VERSION);
    fprintf(stderr, "Type \"%s -help\" for usage information\n", argv[0]);
    if (infile == stdin) {
      fprintf(stderr, "Reading stdin...\n");
    }
    else {
      fprintf(stderr, "Reading %s...\n", argv[iarg]);
    }
  }

  /* Skip commented lines */
  while ((ch = fgetc(infile)) == '#') {
    while ((ch = fgetc(infile)) != '\n') {
      if (ch == EOF) {
	fprintf(stderr, "Error: only comments found in input file\n");
	exit(2);
      }
    }
  }
  ungetc(ch, infile);

  /* Read input data */
  ninputs = fscanf(infile, READ_HEADER_FORMAT, &n,
		   &instrument.wavelength,
		   &instrument.rho_transmitter,
		   &instrument.rho_receiver, &instrument.altitude);
  if (ninputs < 5) {
    fprintf(stderr, "Error: garbled input at first line: "
	    "only %d inputs read successfully\n", ninputs);
    exit(2);
  }
  if (n > MAX_GATES) {
    fprintf(stderr, "Error: too many range gates: maximum %d\n", MAX_GATES);
    exit(2);
  }
  /* If number of samples not specified then it is set equal to the
     number of data levels in the profile */
  if (m == 0) {
    m = n;
  }
  /* Read in the n data levels */
  for (i = 0; i < n; i++) {
    fgets(buffer, MAX_CHARS, infile);
    ninputs = sscanf(buffer, READ_FORMAT, range+i, ext+i,
		     radius+i, ext_bscat_ratio+i, ext_air+i,
		     ssa+i, g+i, ssa_air+i,
		     droplet_fraction+i, pristine_ice_fraction+i);
    if (ninputs < 4) {
      fprintf(stderr, "Error: garbled input at line %d: "
	      "only %d inputs read successfully\n", i+1, ninputs);
      exit(2);
    }
    else if (ninputs < 10) {
      /* Characteristics of the phase function near backscatter have
	 not been entered: use defaults */
      droplet_fraction[i] = 0.0; /* Default: isotropic at 180deg */
      pristine_ice_fraction[i] = 0.0; /* Isotropic at 180deg */
      use_isotropic_pp = 1;
      if (ninputs < 8) {
	/* Wide-angle scattering properties have not been provided:
	   use quasi-small-angle multiple scattering only */
	options |= MS_QSA_ONLY;
	if (ninputs < 5) {
	  /* No air extinction: assume vacuum */
	  ext_air[i] = 0.0;
	  use_air_ext = 0;
	}
      }
    }
  }

  /* Set options */
  ms_set_options(options);

  /* Report activity */
  if (!(options & MS_QUIET)) {
    fprintf(stderr, "Instrument characteristics:\n");
    fprintf(stderr, "   Wavelength: %g m\n", instrument.wavelength);
    fprintf(stderr, "   Gaussian transmitter pattern 1/e half-width: %g radians\n",
	    instrument.rho_transmitter);
    if (instrument.receiver_type == TOP_HAT) {
      fprintf(stderr, "   Top-hat receiver pattern half-width: %g radians\n",
	      instrument.rho_receiver);
    }
    else {
      fprintf(stderr, "   Gaussian receiver pattern 1/e half-width: %g radians\n",
	      instrument.rho_receiver);
    }
    fprintf(stderr, "   Altitude: %g m\n", instrument.altitude);
    fprintf(stderr, "   Distance to first gate: %g m\n", 
	    fabs(instrument.altitude-range[0]));
    fprintf(stderr, "   Receiver full-width footprint at first gate: %g m\n",
	    fabs(instrument.altitude-range[0])*instrument.rho_receiver*2.0);
    if (!output_jacobian) {
      fprintf(stderr, "The output from the following algorithm(s) are summed:\n");
    }
    else {
      fprintf(stderr, "The Jacobian is calculated from the following algorithm(s):\n");
    }
    if (options & MS_NO_FORWARD_LOBE) {
      fprintf(stderr, "   Single scattering\n");
    }
    else if (options & MS_EXPLICIT_QSA) {
      fprintf(stderr, "   Quasi-small-angle scattering using Eloranta-like explicit method\n");
      fprintf(stderr, "      taken to %d orders of scattering\n", norder);
    }
    else if (options & MS_FAST_QSA) {
      fprintf(stderr, "   Quasi-small-angle scattering using O(N) photon variance-covariance (PVC) method\n");
    }
    else {
      fprintf(stderr, "   Quasi-small-angle scattering using O(N^2) photon variance-covariance (PVC) method\n");
    }
    if (use_isotropic_pp || (options & MS_EXPLICIT_QSA)) {
      fprintf(stderr, "      Phase function assumed to be isotropic near 180 degrees\n");
    }
    else {
      fprintf(stderr, "      Using anisotropic phase function near 180 degrees according to specified\n"
	      "      droplet and pristine ice fractions\n");
    }
    if (!(options & MS_QSA_ONLY)) {
      fprintf(stderr, "   Wide-angle scattering using time-dependent two-stream (TDTS) method\n");
    }
  }

  if (m < n) {
    //    fprintf(stderr, "Warning: currently the number of samples (%d) cannot be fewer than\n"
    //	    "   the number of data points; setting them to be equal\n");
    n = m;
  }

  if (!(options & MS_NO_FORWARD_LOBE) && (instrument.receiver_type == GAUSSIAN)
      && !(options & MS_FAST_QSA)) {
    fprintf(stderr, "Warning: PVC algorithm will use a top-hat receiver pattern\n");
  }
  if (instrument.wavelength > 100e-6 && !(options & MS_NO_FORWARD_LOBE)) {
    fprintf(stderr, "Warning: wavelength greater than 100 microns yet using quasi-small-angle scattering;\n"
	    "   should the \"-no-forward-lobe\" option be specified?\n");
  }

  if (!output_jacobian) {
  /* Call multiscatter algorithm */
    /*
    if (ms_options & MS_QSA_ONLY) {
      for (i = 0; i < nrepeats; i++) {
	CHECK(multiscatter_qsa(n, instrument, surface, range, radius,
			       ext, ext_bscat_ratio, ext_air,
			       droplet_fraction, pristine_ice_fraction,
			       bscat));
      }
    }
    else {
    */
      for (i = 0; i < nrepeats; i++) {
	CHECK(multiscatter(n, m, instrument, surface, range, radius,
			   ext, ssa, g, ext_bscat_ratio, ext_air, ssa_air,
			   droplet_fraction, pristine_ice_fraction,
			   bscat));
      }
      /*
    }
      */

    /* Output results */
    if (options & MS_OUTPUT_DISTRIBUTION) {
      msd_print_distribution(stdout);
    }
    else {
    for (i = 0; i < n; i++) {
      fprintf(stdout, "%d %g %g %g %18.9g",
	      i+1, 
	      range[i],
	      ext[i],
	      radius[i],
	      bscat[i]);
      if (options & MS_QSA_LAG) {
	fprintf(stdout, " %g", ms_qsa_lag[i]);
      }
      if ((options & MS_OUTPUT_BSCATS) && (options & MS_EXPLICIT_QSA)) {
	fprintf(stdout, " %g %g %g 0.0 0.0 0.0",
		ms_bscat_single[i],
		ms_bscat_double[i],
		ms_bscat_multi[i]);
      }
      else if ((options & MS_OUTPUT_BSCATS) && ms_bscat_air_multi) {
	fprintf(stdout, " %g %g %g %g %g %g",
		ms_bscat_single[i],
		ms_bscat_double[i],
		ms_bscat_multi[i],
		ms_bscat_air_single[i],
		ms_bscat_air_double[i],
		ms_bscat_air_multi[i]);
	if (output_all && ms_EPcov_multi) {
	  fprintf(stdout, " %g %g %g %g %g %g %g %g",
		  ms_E_once[i],
		  ms_E_multi[i],
		  sqrt(ms_Emu2_once[i]/ms_E_once[i]),
		  sqrt(ms_Emu2_multi[i]/ms_E_multi[i]),
		  sqrt(ms_Pmu2_once[i]/ms_E_once[i]), 
		  sqrt(ms_Pmu2_multi[i]/ms_E_multi[i]),
		  ms_EPcov_once[i]/sqrt(ms_Emu2_once[i]*ms_Pmu2_once[i]), 
		  ms_EPcov_multi[i]/sqrt(ms_Emu2_multi[i]*ms_Pmu2_multi[i]));
	}
      }
      fprintf(stdout, "\n");
    }
    if (m > n) {
      ms_real drange = range[1]-range[0];
      for (i = n; i < m; i++) {
	fprintf(stdout, "%d %g %g %g %18.9g\n",
		i+1, 
		range[n-1]+drange*(i-n+1),
		0.0,
		0.0,
		bscat[i]);
      }
    }
    }
  }
  else {
    /* Calculate the Jacobian */
    ms_real *jacobian_data = malloc((2*n+1)*n*sizeof(ms_real));
    ms_real **d_ln_beta_d_ln_ext = malloc(n*sizeof(ms_real *));
    ms_real **d_ln_beta_d_ln_radius = malloc(n*sizeof(ms_real *));
    ms_real *d_ln_beta_d_ln_ext_bscat_ratio = jacobian_data + 2*n*n;
    int *i_xy = malloc(n*sizeof(int));
    int i, j;
    for (i = 0; i < n; i++) {
      d_ln_beta_d_ln_ext[i] = jacobian_data + i*n;
      d_ln_beta_d_ln_radius[i] = jacobian_data + (n+i)*n;
      i_xy[i] = i;
    }
    for (i = 0; i < nrepeats; i++) {
      CHECK(multiscatter_jacobian(n, m, instrument, surface,
				  range, radius, ext, ssa, g,
				  ext_bscat_ratio, ext_air, ssa_air,
				  droplet_fraction, pristine_ice_fraction,
				  n, n, i_xy, i_xy, 
				  bscat,
				  d_ln_beta_d_ln_ext, d_ln_beta_d_ln_radius, 
				  d_ln_beta_d_ln_ext_bscat_ratio));
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) {
	fprintf(stdout, " %g", d_ln_beta_d_ln_ext[i][j]);
      }
      fprintf(stdout, "\n");
    }
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) {
	fprintf(stdout, " %g", d_ln_beta_d_ln_radius[i][j]);
      }
      fprintf(stdout, "\n");
    }
    for (i = 0; i < n; i++) {
      fprintf(stdout, " %g", d_ln_beta_d_ln_ext_bscat_ratio[i]);
    }
    fprintf(stdout, "\n");
  }

  if (print_stats) {
    ms_print_stats(stderr);
  }

  exit(0);
}
