/* multiscatter.c -- Interface to multiple scattering algorithms

   Copyright (C) 2006-2007 Robin Hogan <r.j.hogan@reading.ac.uk> 

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


   The algorithm is implemented in ANSI C, but a Fortran interface is
   provided.
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* For details of how to call the multiple scattering algorithms, see
   the comments in this header file: */
#include "multiscatter.h"

/* Static variables only accessed within this file are prefixed by "msi_" */
/* Single scattering properties of clouds/aerosol and air, after
   delta-scaling if appropriate */
static ms_real *msi_ext_prime = NULL;
static ms_real *msi_ssa_prime = NULL;
static ms_real *msi_g_prime = NULL;

/* Source terms in the inward and outward directions */
static ms_real *msi_src_power_in = NULL;
static ms_real *msi_src_power_out = NULL;

/* Lateral variance of source photons (m2) */
static ms_real *msi_src_width2 = NULL;

ms_real *ms_qsa_lag = NULL;

/* Factor to account for the fact that single scattered photons that
   are backscattered directly towards the receiver are not all
   received due to the convolution of the transmitter and receiver
   angular response functions */
static ms_real msi_ss_multiplier = 1.0;

/* Number of gates currently allocated in the intermediate
   variables: */
static int msi_num_gates_allocated = 0;

/* Number of gates defined in the last call to the algorithm: */
static int msi_num_gates_defined = 0;

/* Allocate and initialize the intermediate arrays */
static
int
msi_init_intermediate_arrays(int num_gates)
{
  /* Macro for allocating or reallocating memory for a single array */
#define ALLOCATE(target, num_bytes) \
   if ((target = realloc(target, num_bytes)) == NULL) { \
      target = NULL; return MS_FAILURE; } 

  int i;
  if (msi_num_gates_allocated < num_gates) {
    /* Number of gates allocated is less than number requested (which
       may be zero if this function has not been called): (re)allocate
       memory. */
    int num_bytes = num_gates * sizeof(ms_real);
    msi_num_gates_allocated = 0; /* In case error occurs */
    ALLOCATE(msi_ext_prime, num_bytes);
    ALLOCATE(msi_ssa_prime, num_bytes);
    ALLOCATE(msi_g_prime, num_bytes);
    ALLOCATE(msi_src_power_in, num_bytes);
    ALLOCATE(msi_src_power_out, num_bytes);
    ALLOCATE(msi_src_width2, num_bytes);
    ALLOCATE(ms_qsa_lag, num_bytes);
  }
  msi_num_gates_allocated = num_gates;
  /* Set each element of each array to zero. */
  for (i = -1; i <= num_gates; i++) {
    msi_ext_prime[i] = 0.0;
    msi_ssa_prime[i] = 1.0;
    msi_g_prime[i] = 0.0;
    msi_src_power_in[i] = 0.0;
    msi_src_power_out[i] = 0.0;
    msi_src_width2[i] = 0.0;
    ms_qsa_lag[i] = 0.0;
  }
  msi_num_gates_defined = num_gates;
  return MS_SUCCESS;
}

/* Free the memory associated with the intermediate arrays */
static
void
msi_free_intermediate_arrays()
{
  if (msi_num_gates_allocated > 0) {
    free(msi_ext_prime);
    free(msi_ssa_prime);
    free(msi_g_prime);
    free(msi_src_power_in);
    free(msi_src_power_out);
    free(msi_src_width2);
    free(ms_qsa_lag);
  }
  msi_num_gates_allocated = 0;
  msi_num_gates_defined = 0;
}

/* Perform the multiple scattering calculation by summing single
   scattering and wide-angle scattering - this is appropriate for
   radar where the phase function does not have a strong forward lobe
   that needs to be treated separately. */
static
int
multiscatter_no_forward_lobe(int n, int m, ms_instrument instrument,
	     ms_surface surface, ms_real *range, ms_real *radius,  
	     ms_real *ext, ms_real *ssa, ms_real *g,
	     ms_real *ext_bscat_ratio,
	     ms_real *ext_air, ms_real *ssa_air,
	     ms_real *bscat_out)
{
  ms_real optical_depth = 0.0, transmittance = 1.0;
  ms_real drange = fabs(range[2]-range[1]);
  ms_real bscat_ext_ratio_air = 3.0 / (8.0 * MS_PI);
  int status = MS_SUCCESS;
  int i;

  msi_init_intermediate_arrays(n);

  /* Calculate the combined single scattering properties of
     cloud/aerosol and air; note that no delta scaling is applied
     since no forward lobe is present. */
  if (ext_air && ssa_air) {
    /* Add the gas and particle contributions */
    for (i = 0; i < n; i++) {
      msi_ext_prime[i] = ext_air[i] + ext[i];
      if (msi_ext_prime[i] <= 0.0) {
	msi_ssa_prime[i] = 0.0;
	msi_g_prime[i] = 0.0;
      }
      else {
	msi_ssa_prime[i] = (ext_air[i]*ssa_air[i] + ext[i]*ssa[i])
	  / (ext_air[i]+ext[i]);
	/* The following assumes any molecular scattering to be
	   isotropic (i.e. its g is zero) */
	msi_g_prime[i] = ext[i]*ssa[i]*g[i]
	  /(ext_air[i]*ssa_air[i] + ext[i]*ssa[i]);
      }
    }
  }
  else {
    for (i = 0; i < n; i++) {
      msi_ext_prime[i] = ext[i];
      msi_ssa_prime[i] = ssa[i];
      msi_g_prime[i] = g[i];
    }
  }

  /* Calculate the single-scatter contribution to the backscatter as
     well as the source terms for the wide-angle calculation */
  for (i = 0; i < n; i++) {
    ms_real od = msi_ext_prime[i]*drange; /* optical depth of layer */
    ms_real src_power;
    if (od > 0.0) {
      transmittance = exp(-optical_depth)*(1-exp(-od))/od;
      optical_depth += od;
    }
    else {
      transmittance = exp(-optical_depth);
    }
    /* The single-scattering backscatter is the sum of the
       contribution from cloud/aerosol and air, multiplied by the
       transmittance squared. Note that we are assuming that if the
       air molecules can scatter then they will behave as Rayleigh
       scatterers. */
    if (ext_air && ssa_air) {
      bscat_out[i] = transmittance*transmittance
	*(ext[i]/ext_bscat_ratio[i] + ext_air[i]*ssa_air[i]*bscat_ext_ratio_air);
    }
    else {
      bscat_out[i] = transmittance*transmittance*ext[i]/ext_bscat_ratio[i];
    }
    //    src_power = msi_ss_multiplier*transmittance
    //      *(ext[i]*ssa[i]+ext_air[i]*ssa_air[i])*drange;
    src_power = msi_ss_multiplier*exp(-optical_depth+od)
      *(1-exp(-msi_ext_prime[i]*msi_ssa_prime[i]*drange));

    if (msi_g_prime[i] >= 1.0/(3.0*MS_MU1)) {
      /* If g exceeds 2/3, all energy is sent into outward diffuse stream */
      msi_src_power_in[i] = 0.0;
      msi_src_power_out[i] = src_power;
    }
    else if (msi_g_prime[i] <= -1.0/(3.0*MS_MU1)) {
      /* If g is less than -2/3, all energy is sent into inward
	 diffuse stream (this never happens in atmospheric
	 scattering) */
      msi_src_power_in[i] = src_power;
      msi_src_power_out[i] = 0.0;
    }
    else {
      /* Two-stream phase function */
      msi_src_power_in[i] = src_power*0.5*(1.0-3.0*msi_g_prime[i]*MS_MU1);
      msi_src_power_out[i] = src_power*0.5*(1.0+3.0*msi_g_prime[i]*MS_MU1);
    }
    msi_src_width2[i] = instrument.rho_transmitter*instrument.rho_transmitter
      *(range[i]-instrument.altitude)*(range[i]-instrument.altitude);
  }

  if (!(ms_options & MS_QSA_ONLY)) {
    /* Perform two-stream calculation */
    status = multiscatter_2s(n, m, instrument, surface, range,
			     msi_ext_prime, msi_ssa_prime, msi_g_prime,
			     msi_src_power_in, msi_src_power_out,
			     msi_src_width2, bscat_out);
  }
  return status;
}

/* Return some useful statistics */
int
ms_get_stats(ms_real *total_src, ms_real *total_reflected,
	     ms_real *ss_multiplier)
{
  ms2_get_stats(total_src, total_reflected);
  *ss_multiplier = msi_ss_multiplier;
  return MS_SUCCESS;
}

/* Print statistics to a stream */
int
ms_print_stats(FILE *file)
{
  ms_real total_src, total_reflected;
  fprintf(file, "Single-scattering multiplier: %g\n", msi_ss_multiplier);
  if (ms2_get_stats(&total_src, &total_reflected) == MS_SUCCESS) {
    fprintf(file, "Total 2-stream source: %g\n", total_src);
    fprintf(file, "Total 2-stream reflected: %g\n", total_reflected);
  }
  return MS_SUCCESS;
}

/* Interface to multiple scattering calculation */
int
multiscatter(int n, int m, ms_instrument instrument, ms_surface surface, 
	     ms_real *range, ms_real *radius,  
	     ms_real *ext, ms_real *ssa, ms_real *g,
	     ms_real *ext_bscat_ratio,
	     ms_real *ext_air, ms_real *ssa_air,
	     ms_real *droplet_fraction, ms_real *ice_fraction,
	     ms_real *bscat_out)
{
  ms_real optical_depth = 0.0, transmittance = 1.0;
  ms_real drange = fabs(range[2]-range[1]);
  int status;
  int i;

  /* Work out single-scattering factor */
  if (instrument.receiver_type == TOP_HAT) {
    msi_ss_multiplier = 1.0/(1.0-exp(-instrument.rho_receiver*instrument.rho_receiver/
				     (instrument.rho_transmitter*instrument.rho_transmitter)));
  }
  else {
    msi_ss_multiplier = 1.0 + instrument.rho_transmitter*instrument.rho_transmitter
      /(instrument.rho_receiver*instrument.rho_receiver);
  }

  /* If no forward lobe (radar case) then this function sums the
     single-scattering and wide-angle multiple-scattering returns */
  if (ms_options & MS_NO_FORWARD_LOBE) {
    return multiscatter_no_forward_lobe(n, m, instrument, surface,
					range, radius,  
					ext, ssa, g,
					ext_bscat_ratio,
					ext_air, ssa_air,
					bscat_out);
  }

  msi_init_intermediate_arrays(n);

  /* Perform quasi-small-angle multiple-scattering calculation */
  if (!(ms_options & MS_EXPLICIT_QSA)) {

    if (ms_options & MS_FAST_QSA && ms_options & MS_QSA_LAG) {
      status = multiscatter_fastqsa_lag(n, instrument, surface, range, radius,
				    ext, ext_bscat_ratio, ext_air,
				    droplet_fraction,
				    ice_fraction,bscat_out, ms_qsa_lag);
    }
    else if (ms_options & MS_FAST_QSA) {
      status = multiscatter_fastqsa(n, instrument, surface, range, radius,
				    ext, ext_bscat_ratio, ext_air,
				    droplet_fraction,
				    ice_fraction,bscat_out);
    }
    else {
      status = multiscatter_qsa(n, instrument, surface, range, radius,
				ext, ext_bscat_ratio, ext_air,
				droplet_fraction, ice_fraction, 
				bscat_out);
    }
  }
  else {
    status = multiscatter_explicit(n, 
				   instrument, surface, range, radius,
				   ext, ext_bscat_ratio, ext_air, ssa_air,
				   bscat_out);
  }
  if (status != MS_SUCCESS || !ssa || !g || ms_options & MS_QSA_ONLY) {
    /* Return if status is non-zero (indicating that an error
       occurred) or if ssa or g are not set (indicating that the
       wide-angle calculation is not to be performed). */
    return status;
  }

  /* Now calculate the source terms for the wide-angle calculation */
  ms_variance(n, instrument.wavelength, instrument.rho_transmitter,
	      instrument.altitude,
	      range, radius, ext, msi_src_width2);

  for (i = 0; i < n; i++) {
    ms_real od, od_factor, power_factor, src_power, g_equiv, wide_factor;
    if (ms_options & MS_SSA_SCALES_FORWARD_LOBE) { // || ssa[i] < 0.5/g[i]) {
      /* Single-scattering albedo of less than one acts to reduce the
	 phase function for all angles; this means that both the
	 forward lobe enhancement to the transmission is reduced, and
	 the side-scattered power is reduced */
      /* Note that currently this option is not treated at all in the
	 multiscatter_qsa() function */
      od_factor = 2.0-ssa[i];
      power_factor = ssa[i];
    }
    else if (ssa[i] > 0.5) {
      /* For single-scattering albedo of greater than 0.5, assume all
	 the absorption affects only the wide-angle part of the phase
	 function, not the forward lobe */
      od_factor = 1.0;
      power_factor = 2.0*ssa[i]-1.0;
    }
    else {
      /* For single-scattering albedo less than 0.5, assume that there
	 is no wide-angle scattering and now the forward lobe starts
	 to be reduced */
      od_factor = 2.0*(1.0-ssa[i]);
      power_factor = 0.0;
    }
    
    /* Calculate the optical depth to the start of gate i */
    if (ext_air) {
      od = (0.5*ext[i]*od_factor + ext_air[i])*drange;
    }
    else {
      od = 0.5*ext[i]*od_factor*drange;
    }
    /* Calculate the transmittance to gate i, including in-gate
       attenuation */
    if (od > 0.0) {
      transmittance = exp(-optical_depth)*(1-exp(-od))/od;
      optical_depth += od;
      if (ext_air && ssa_air) {
	wide_factor = (ext[i]*ssa[i] + ext_air[i]*ssa_air[i])
	  /(0.5*ext[i]*power_factor + ext_air[i]*ssa_air[i]);
      }
      else {
	wide_factor = ext[i]*ssa[i]/(0.5*ext[i]*power_factor);
      }
    }
    else {
      transmittance = exp(-optical_depth);
      wide_factor = 1.0;
    }
    
    /* Calculate source power and source width-squared for the
       wide-angle calculation */
    if (ext_air && ssa_air) {
      src_power = msi_ss_multiplier*transmittance
	*(0.5*ext[i]*power_factor + ext_air[i]*ssa_air[i])*drange;
    }
    else {
      src_power = msi_ss_multiplier*transmittance
	*0.5*ext[i]*power_factor*drange;
    }
    g_equiv = 1-wide_factor+wide_factor*g[i];
    if (g_equiv >= 1.0/(3.0*MS_MU1)) {
      msi_src_power_in[i] = 0.0;
      msi_src_power_out[i] = src_power;
    }
    else {
      msi_src_power_in[i] = src_power*0.5*(1.0-3.0*g_equiv*MS_MU1);
      msi_src_power_out[i] = src_power*0.5*(1.0+3.0*g_equiv*MS_MU1);
    }
  }

  if (ext_air && ssa_air) {
    /* Weighted delta scaling assuming that the gaseous asymmetry
       factor is 0.0 */
    for (i = 0; i < n; i++) {
      msi_ext_prime[i] = ext_air[i] + ext[i]*(1.0-ssa[i]*g[i]*g[i]);
      if (ext_air[i] + ext[i] <= 0.0) {
	msi_ssa_prime[i] = 0.0;
	msi_g_prime[i] = 0.0;
      }
      else {
	msi_ssa_prime[i] = (ext_air[i]*ssa_air[i]
			    + ext[i]*ssa[i]*(1.0-g[i]*g[i])/(1.0-ssa[i]*g[i]*g[i]))
	  / (ext_air[i]+ext[i]);
	/* Assume g of air is zero (isotropic scattering) */
	msi_g_prime[i] = ext[i]*ssa[i]*g[i]/((1.0+g[i])
					     *(ext_air[i]*ssa_air[i]+ext[i]*ssa[i]));
      }
    }
  }
  else {
    /* Standard delta scaling without air contribution */
    for (i = 0; i < n; i++) {
      msi_ext_prime[i] = ext[i]*(1.0-ssa[i]*g[i]*g[i]);
      msi_ssa_prime[i] = ssa[i]*(1.0-g[i]*g[i])/(1.0-ssa[i]*g[i]*g[i]);
      msi_g_prime[i] = g[i]/(1.0+g[i]);
    }
  }

  /* Perform the 2-stream wide-angle multiple scattering
     calculation */
  status = multiscatter_2s(n, m, instrument, surface, range,
			   msi_ext_prime, msi_ssa_prime, msi_g_prime,
			   msi_src_power_in, msi_src_power_out,
			   msi_src_width2, bscat_out);
  return status;
}
